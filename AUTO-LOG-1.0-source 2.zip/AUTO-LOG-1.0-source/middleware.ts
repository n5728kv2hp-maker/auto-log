import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
export async function middleware(req:NextRequest){
 let res=NextResponse.next({request:req});
 const supabase=createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,{
  cookies:{get(name){return req.cookies.get(name)?.value},set(name,value,options){req.cookies.set({name,value,...options});res=NextResponse.next({request:req});res.cookies.set({name,value,...options})},remove(name,options){req.cookies.set({name,value:"",...options});res=NextResponse.next({request:req});res.cookies.set({name,value:"",...options})}}
 });
 await supabase.auth.getUser(); return res;
}
export const config={matcher:["/((?!_next/static|_next/image|favicon.ico|.*\\\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"]};